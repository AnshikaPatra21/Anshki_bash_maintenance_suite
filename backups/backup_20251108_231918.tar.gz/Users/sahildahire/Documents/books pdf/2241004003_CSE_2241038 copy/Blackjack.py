import random
from enum import Enum

# Enum for Suit class
class Suit(Enum):
    HEARTS = "Hearts"
    DIAMONDS = "Diamonds"
    CLUBS = "Clubs"
    SPADES = "Spades"

# Card class
class Card:
    def __init__(self, suit, rank):
        self.suit = suit
        self.rank = rank

    def __repr__(self):
        return f"{self.rank} of {self.suit.value}"

    def get_value(self):
        if self.rank in ['Jack', 'Queen', 'King']:
            return 10
        elif self.rank == 'Ace':
            return 11  # Initially, Ace is 11, can be adjusted later
        else:
            return int(self.rank)

# Deck class
class Deck:
    def __init__(self):
        ranks = ['2', '3', '4', '5', '6', '7', '8', '9', '10', 'Jack', 'Queen', 'King', 'Ace']
        self.cards = [Card(suit, rank) for suit in Suit for rank in ranks]
        random.shuffle(self.cards)

    def draw_card(self):
        return self.cards.pop() if self.cards else None

# Player class
class Player:
    def __init__(self, name):
        self.name = name
        self.hand = []

    def add_card(self, card):
        if card:
            self.hand.append(card)

    def get_hand_value(self):
        value = sum(card.get_value() for card in self.hand)
        ace_count = sum(1 for card in self.hand if card.rank == 'Ace')
        while value > 21 and ace_count:
            value -= 10  # Convert Ace from 11 to 1
            ace_count -= 1
        return value

    def __repr__(self):
        return f"{self.name}'s Hand: {', '.join(map(str, self.hand))} (Total: {self.get_hand_value()})"

# Blackjack Game class
class Blackjack:
    def __init__(self, player_names):
        self.deck = Deck()
        self.players = [Player(name) for name in player_names]
        self.dealer = Player("Dealer")
        
        # Initial dealing
        for _ in range(2):
            for player in self.players:
                player.add_card(self.deck.draw_card())
            self.dealer.add_card(self.deck.draw_card())

    def play(self):
        for player in self.players:
            while player.get_hand_value() < 21:
                print(f"\n{player}")
                move = input(f"{player.name}, do you want to hit or stand? (h/s): ").strip().lower()
                if move == 'h':
                    card = self.deck.draw_card()
                    if card:
                        player.add_card(card)
                        print(f"{player.name} draws {card}!")
                    else:
                        print("Deck is empty!")
                else:
                    print(f"{player.name} decides to stand.")
                    break
        
        # Dealer's turn
        print("\nDealer's turn...")
        while self.dealer.get_hand_value() < 17:
            card = self.deck.draw_card()
            if card:
                self.dealer.add_card(card)
                print(f"Dealer draws {card}!")
            else:
                print("Deck is empty!")
                break
        
        print("\nFinal Hands:")
        print(self.dealer)
        for player in self.players:
            print(player)
            if player.get_hand_value() > 21:
                print(f"{player.name} busts! Dealer wins.")
            elif self.dealer.get_hand_value() > 21 or player.get_hand_value() > self.dealer.get_hand_value():
                print(f"{player.name} wins!")
            elif player.get_hand_value() < self.dealer.get_hand_value():
                print(f"{player.name} loses.")
            else:
                print(f"{player.name} and the dealer tie!")

# Run the game
if __name__ == "__main__":
    player_names = input("Enter player names (comma-separated): ").split(', ')
    game = Blackjack(player_names)
    game.play()
